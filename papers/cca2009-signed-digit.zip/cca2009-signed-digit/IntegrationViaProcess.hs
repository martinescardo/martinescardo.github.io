-- Martin Escardo
-- For CCA'2009, based on older stuff.

module IntegrationViaProcess
  (
   halfIntegralViaProcess, 
   halfIntegralProcess
  ) where

import Iquantification
import BasicArithmetic
import IteratedMidPoint
import ProcessRepresentation

-- We represent a number x in [-1,1] by a sequence a in [I] 
-- such that x = bigMid a.

average :: [I] -> [I] -> [I]
average = zipWith mid

-- Definite integration. Based on A.K. Simpson 1998, but there 
-- are a couple of new ideas, such as using the above 
-- representation.
--
-- Compute integral of f from -1 to 1 divided by 2.


halfIntegralProcess :: Process -> [I]

halfIntegralProcess (Output d p) = (repeat d) : halfIntegralProcess p
halfIntegralProcess (Input p q r) = average (halfIntegralProcess p) 
                                            (halfIntegralProcess r)

halfIntegralViaProcess :: (I -> I) -> I
halfIntegralViaProcess f = bigMid(halfIntegralProcess (toProcess f))

