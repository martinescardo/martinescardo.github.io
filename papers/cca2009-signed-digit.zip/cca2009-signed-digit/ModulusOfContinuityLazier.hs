-- Martin Escardo
-- For CCA'2009, based on older stuff.

module ModulusOfContinuityLazier (modulusLazier, modulusLazier') where

import Iquantification
import BasicArithmetic
import IteratedMidPoint

-- Modulus of uniform continuity on [-1,1]

data LazierNat = Z | S LazierNat | B LazierNat
               deriving (Show)

lazyMax Z y = y
lazyMax x Z = x
lazyMax (B x) y = B(lazyMax x y)
lazyMax x (B y) = B(lazyMax x y)
lazyMax (S x) (S y) = S(lazyMax x y)

modulusLazier :: (I -> I) -> (Int -> LazierNat)

modulusLazier f 0 = Z
modulusLazier f n = if forEveryI(\x -> head(f x) == head (f zero))
              then B(modulusLazier (tail.f) (n-1))
              else S(lazyMax (modulusLazier (f.((-1):)) n) 
                             (modulusLazier (f.(( 1):)) n))

lazySize :: LazierNat -> [Int]

lazySize n = f 0 n
 where f m Z = [m]
       f m (B n) = m : f(m+1) n
       f m (S n) = m : f(m+1) n

-- Counts how many universal quantifications are performed:

modulusLazier' :: (I -> I) -> (Int -> [Int])
modulusLazier' f n = lazySize (modulusLazier f n)
