-- Martin Escardo
-- For CCA'2009, based on older stuff.

module ElementaryFunctions 
  (
    mexp, 
    msin, 
    mcos, 
    marctan, 
    marcsin, 
    mlni, 
    mln, 
    piDividedBy4, 
    piDividedBy32
  ) where

import IteratedMidPoint
import BasicArithmetic
import TruncatedArithmetic


-- Exponential function 1/2 e^(x/2)

mexp :: I -> I
mexp x = bigMid(series one 1)
     where series y n = y : series (divByInt (mul x y) n) (n+1)


-- Trigonometric function 1/2 sin(x/2)

msin :: I -> I

msin x = bigMid(series x 2)
 where x2 = compl(sqr x)
       series y n = zero : y : 
                    series(divByInt(mul x2 y)(n*(n+1)))(n+2)

-- Trigonometric function 1/2 cos(x/2)

mcos :: I -> I

mcos x = bigMid(series one 1)
 where x2 = compl(sqr x)
       series y n = y : zero : 
                    series(divByInt(mul x2 y)(n*(n+1)))(n+2)

-- Function 1/2 arctan(x/2)

marctan :: I -> I

marctan x = bigMid(series x 1)
      where x2 = compl(sqr x)
            series y n = zero : divByInt y n : 
                         series (mul x2 y) (n+2)

-- Number pi:
--
-- Use K. Takano 1982:
-- pi/4 = 12 arctan(1/49) 
--      + 32 arctan1/57) 
--      - 5 arctan(1/239) 
--      + 12 arctan(1/110443)

piDividedBy4 :: I
piDividedBy4 = let inverse n = divByInt one n
                   arctan = mulBy2.marctan.mulBy2 
                   y1 = tMulByInt (arctan(inverse 49)) 12
                   y2 = tMulByInt (arctan(inverse 57)) 32
                   y3 = compl(tMulByInt (arctan(inverse 239)) 5)
                   y4 = tMulByInt (arctan(inverse 110443)) 12
               in add (add y1 y2) (add y3 y4)

-- Another definition of the number pi
--
-- Using Bailey, Borwein & Plouffe 1997, we get:
--
-- pi/8 = 
--
--bigMid_k 8^{-k} (1/(8k+1) - 1/2(8k+4) - 1/4(8k+5) - 1/4(8k+6))

piDividedBy32 :: I

piDividedBy32 = 
 bigMid 
 [f k (mid (mid (g1 k) (g2 k))(mid (g3 k) (g4 k))) | k <- [0..]]
  where f k x = if k == 0 then x else 0:0:0: f (k-1) x
        g1 k = divByInt (repeat  1)      (8*k+1)
        g2 k = divByInt (-1 : zero)      (8*k+4)
        g3 k = divByInt ( 0 : -1 : zero) (8*k+5)
        g4 k = divByInt ( 0 : -1 : zero) (8*k+6)



-- Trigonometric function 1/2 arcsin(x/2)/2

marcsin :: I -> I

marcsin x = bigMid(series x 1)
 where x2 = sqr x
       series y n = zero : divByInt y n : 
                    series (tMulByInt (divByInt (mul x2 y) 
                                          (n+1)) n) (n+2)


-- Logarithmic function ln(1+x/2)/x
-- When x = 0 we get the limit, namely 1/2.

mlni :: I -> I

mlni x = bigMid(series one 1)
      where x2 = compl x
            series y n = divByInt y n : series (mul x2 y) (n+1)

-- Truncated logarithmic function ln(1+x/2)

mln :: I -> I

mln x = mul x (mlni x)
