-- Martin Escardo
-- For CCA'2009, based on older stuff.

-- Convenient I/O

module DoubleConversion (toDouble, fromDouble) where

import BasicArithmetic

toDouble :: I -> Double

toDouble = f 54
  where f 0 x = 0.0
        f k (-1 : x) = (-1.0 + f (k-1) x)/2.0
        f k ( 0 : x) = (       f (k-1) x)/2.0
        f k ( 1 : x) = ( 1.0 + f (k-1) x)/2.0
        f k [] = 0

fromDouble :: Double -> I

fromDouble = f 54
  where f 0 x   = zero
        f k x   = if x  < 0.0 then -1 : f (k-1) (2.0 * x + 1)
                              else  1 : f (k-1) (2.0 * x - 1)

