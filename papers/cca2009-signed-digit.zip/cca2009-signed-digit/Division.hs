-- Martin Escardo
-- For CCA'2009, based on older stuff.

module Division (inv) where

import BasicArithmetic (I, one, mul)
import IteratedMidPoint

-- The inverse function 1 / (2 - x) using power series.

inv :: I -> I
inv x = bigMid(series one)
     where series y = y : series (mul x y)
