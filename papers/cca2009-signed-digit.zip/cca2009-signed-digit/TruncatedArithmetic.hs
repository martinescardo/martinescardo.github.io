-- Martin Escardo
-- For CCA'2009, based on older stuff.

module TruncatedArithmetic 
  ( 
   addOne, 
   subOne, 
   oneMinus, 
   mulBy2, 
   mulBy4, 
   add, 
   iabs,
   imin,
   imax,
   tMulByInt
  ) where

import BasicArithmetic

-- Some "truncated operatations".
-- The truncation map R -> [-1,1] is mathematically defined as
--
--       truncate(x) = max(-1,min(x,1))
--
--                      /
--                      |    -1 if x <= -1
--                   = <      x if      -1 <= x <= 1
--                      |     1 if                 1 <= x
--                      \


-- Truncated x+1 as a function [-1,1] -> [-1,1]
-- x |-> min(x+1,1)

addOne :: I -> I

addOne ( 1 : x) = one
addOne ( 0 : x) = 1 : addOne x
addOne (-1 : x) = 1 : x

-- Truncated x-1 as a function [-1,1] -> [-1,1]
-- x |-> max(-1,x-1)

subOne :: I -> I

subOne ( 1 : x) = -1 : x
subOne ( 0 : x) = -1 : subOne x
subOne (-1 : x) = minusOne

-- Truncated 1-x as a function [-1,1] -> [-1,1]

oneMinus :: I -> I

oneMinus = addOne.compl

-- Truncated multiplication by 2 as a function [-1,1] -> [-1,1]
-- x |-> max(-1,min(2x,1))

mulBy2 :: I -> I

mulBy2 ( 1 : x)  = addOne x
mulBy2 ( 0 : x)  = x
mulBy2 (-1 : x)  = subOne x

-- Truncated multiplication by 4

mulBy4 :: I -> I

mulBy4 = mulBy2.mulBy2

-- Truncated addition as a function [-1,1] x [-1,1] -> [-1,1]
-- (x,y) |- max(-1,min(x+y,1))

add :: I -> I -> I

add x y = mulBy2(mid x y)

-- Truncated multiplication of a number by 
-- non-negative integer.

tMulByInt :: I -> Int -> I

tMulByInt x 0 = zero
tMulByInt x 1 = x
tMulByInt x n = if even n 
               then mulBy2(tMulByInt x (n `div` 2)) 
               else add x (mulBy2(tMulByInt x (n `div` 2)))

-- The minimum function 

imin :: I -> I -> I

imin ( a : x) ( b : y) | a == b = a : imin x y
imin (-1 : x) ( 1 : y) = -1 : x
imin ( 1 : x) (-1 : y) = -1 : y
imin (-1 : x) ( 0 : y) = -1 : imin           x     (oneMinus y) 
imin ( 0 : x) (-1 : y) = -1 : imin (oneMinus x)              y
imin ( 1 : x) ( 0 : y) =  0 : imin (addOne   x)              y
imin ( 0 : x) ( 1 : y) =  0 : imin           x       (addOne y)

-- The maximum function by "cheating"

imax :: I -> I -> I

imax x y = compl (imin (compl x) (compl y))

-- The absolute-value function 

iabs x = imax (compl x) x
