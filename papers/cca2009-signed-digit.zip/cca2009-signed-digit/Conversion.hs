-- Martin Escardo
-- For CCA'2009, based on older stuff.

-- Conversion to decimal (when possible).

module Conversion 
   (
     Decimal, 
     signedDecimal, 
     decimal,
     decimalString
   ) where

import BasicArithmetic (I, mulByInt)

-- Using negative digits first.

type Decimal = [Int] 

signedDecimal :: I -> Decimal
signedDecimal x = let (m,y) = mulByInt x 10 
                  in m : signedDecimal y

-- Get rid of negative digits. Only works for positive, 
-- non-10-adic numbers. 

normalize :: Decimal -> Decimal
normalize x = f x
 where f(d:x) = if wpositive x
                then d:f x
                else (d-1): g x
       g(0:x) = 9: g(x)
       g(d:x) = if wpositive x
                then (10+d) : f x
                else (10+d-1) : g x

-- wpositive diverges for 10-adic numbers.

wpositive :: Decimal -> Bool
wpositive (d:x) = 
  if d > 0 then True else if d < 0 then False else wpositive x 

-- Converts a non-negative, non 10-adic, number to decimal 
-- notation using only non-negative digits

decimal :: I -> Decimal
decimal = normalize.signedDecimal

decimalString :: I -> String
decimalString = concat.(map show).decimal
