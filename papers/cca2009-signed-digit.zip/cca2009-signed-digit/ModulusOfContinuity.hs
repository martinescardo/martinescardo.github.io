-- Martin Escardo
-- For CCA'2009, based on older stuff.

module ModulusOfContinuity (modulus) where

import Iquantification
import BasicArithmetic
import IteratedMidPoint

-- Modulus of uniform continuity on [-1,1]

modulus :: (I -> I) -> (Int -> Int)

modulus f 0 = 0 
modulus f n = if forEveryI(\x -> head(f x) == head (f zero))
              then modulus (tail.f) (n-1) 
              else 1 + max (modulus (f.((-1):)) n) (modulus (f.(1:)) n)


