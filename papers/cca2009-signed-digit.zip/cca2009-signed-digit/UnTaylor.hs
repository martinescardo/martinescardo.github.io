-- Martin Escardo
-- For CCA'2009, based on older stuff.

module UnTaylor 
  (
    taylor, 
    unTaylor, 
    powerf, 
    unPower, 
    isNotAnalytic, 
    traceAnalytic
  ) where

import BasicArithmetic
import IteratedMidPoint
import Selection
import DecidableCloseness
import Minimization

-- Given a sequence of reals x_n in [-1,1],
-- there is a unique function 

taylor :: [I] -> (I -> I)
unTaylor :: Int -> (I -> I) -> [I]

taylor a x = bigMid (series one 1 a)
 where series y n (z:b) = mul z y : 
                          series(mul x (divByInt y n)) (n+1) b

unTaylor n f = findSequence(\a -> closeFun n (taylor a) f)


-- Closely related stuff 

powerf :: [I] -> (I -> I)
unPower :: Int -> (I -> I) -> [I]

powers x = one : map (mul x) (powers x)

powerf a x = bigMid (series one a)
 where series y (z:b) = (mul z y) : series (mul x y) b

unPower n f = findSequence(\a -> closeFun n (powerf a) f)



-- Checking whether a function is not "analytic" (with slightly
-- non-standard of "analytic").  This is a semi-decidable test. 

isNotAnalytic :: (I -> I) -> Int

isNotAnalytic f = 
  mu(\n -> not(forSomeSequence(\a -> closeFun n (taylor a) f)))

traceAnalytic :: (I -> I) -> [Int]

traceAnalytic f = t 0
 where t n = n : 
        if forSomeSequence(\a -> closeFun n (taylor a) f)
        then t(n+1)
        else []

