-- Martin Escardo
-- For CCA'2009, based on older stuff.

module Selection 
  (
    prod, 
    findDigit, 
    findReal, 
    forEveryReal, 
    forSomeReal, 
    findSequence, 
    forSomeSequence
  ) where

import BasicArithmetic

-- LICS 2007 product functional (and related stuff)


prod :: [(a -> b) -> a] -> ([a] -> b) -> [a]
prod (e:es) p = 
  x:prod es (p.(x:)) where x = e(\y->p(y:prod es (p.(y:))))

findDigit :: (Digit -> Bool) -> Digit
findDigit p = if p 1 then 1 else -1

findReal :: (I -> Bool) -> I
findReal = prod(repeat findDigit)

forSomeReal, forEveryReal :: (I -> Bool) -> Bool
forSomeReal p = p(findReal p)
forEveryReal p = not(forSomeReal(not.p))

findSequence :: ([I] -> Bool) -> [I] 
findSequence = prod(repeat findReal)

forSomeSequence p = p(findSequence p)


-- Integration
-- Berger's quantification algorithm (Simpson's version)

type Two   = Int    -- use  0,1
type Cantor = [Two] -- The Cantor space.

counterExample :: (Cantor -> Bool) -> Cantor
counterExample p = 
  let a = 0:counterExample(p.(0:)) 
  in if p a then 1:counterExample(p.(1:)) else a

forEvery :: (Cantor -> Bool) -> Bool
forEvery p = p(counterExample(p))

forEveryDigit :: (Digit -> Bool) -> Bool
forEveryDigit p = p(0) && p(-1) && p(1)
