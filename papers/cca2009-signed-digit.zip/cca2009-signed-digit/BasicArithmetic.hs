-- Martin Escardo
-- For CCA'2009, based on older stuff.

module BasicArithmetic 
  (
    I, 
    Digit, 
    one, 
    zero, 
    minusOne, 
    mid, 
    compl, 
    digitMul, 
    mul,
    sqr,  
    divByInt, 
    mulByInt,
    znorm
  ) where

-- Some digit alphabets:

type Digit   = Int   -- use -1,0,1
type Digit'  = Int   -- use -2,-1,0,1,2 (not exported)

-- We use binary notation with the above digit sets:

type I  = [Digit]   -- Representation of the space [-1,1]      *
type I2 = [Digit']  -- Representation of the space [-2,2]

-- Some constants:

one, zero, minusOne :: I

one = repeat 1
zero = repeat 0
minusOne = repeat (-1)

-- Addition as a function [-1,1] x [-1,1] -> [-2,2]

add2 :: I -> I -> I2
add2 = zipWith (+)


-- Division by 2 as a function [-2,2] -> [-1,1]

divideBy2 :: I2 -> I
divideBy2 ((-2):x) = -1 : divideBy2 x 
divideBy2 (( 0):x) =  0 : divideBy2 x
divideBy2 (( 2):x) =  1 : divideBy2 x
divideBy2 (a:b:x) = 
  let d = 2 * a + b
  in if      d < -2 then -1 : divideBy2((d+4):x)
     else if d >  2 then  1 : divideBy2((d-4):x)
                    else  0 : divideBy2(d:x)               

-- Midpoint (x+y)/2 as a function [-1,1] x [-1,1] -> [-1,1]

mid :: I -> I -> I
mid x y = divideBy2(add2 x y)


-- Complemente f(x) = -x as a function [-1,1] -> [-1,1]

compl :: I -> I
compl = map (\a -> -a)


-- Multiplication of a signed digit in 3 by a number in [-1,1]

digitMul :: Digit -> I -> I
digitMul (-1) x = compl x
digitMul 0 x = zero
digitMul 1 x = x



-- More efficient multiplication [-1,1] x [-1,1] -> [-1,1]
--
-- Follows from simple algebraic law for mulplication and 
-- midpoint.

mulPlume :: I -> I -> I

mulPlume (a0 : a1 : x) (b0 : b1 : y) = mid p q
  where p  = mid p' p''
        p' = (a0*b1): mid (digitMul b1 x) (digitMul a1 y)
        p''= mid (digitMul b0 x) (digitMul a0 y)
        q = (a0*b0) : (a1*b0) : (a1*b1) : mulPlume x y

-- Even more efficient.
-- Consider particular cases of the previous.

mulMartin :: I -> I -> I

mulMartin (0:x) y = 0 : mulMartin x y
mulMartin x (0:y) = 0 : mulMartin x y
mulMartin (a0 : 0 : x) (b0 : 0 : y) = mid p q
  where p  = 0 : mid (digitMul b0 x) (digitMul a0 y)
        q = (a0*b0) : 0 : 0 : mulMartin x y
mulMartin (a0 : 0 : x) (b0 : b1 : y) = mid p q
  where p  = mid p' p''
        p' = (a0*b1): 0 : digitMul b1 x
        p''= mid (digitMul b0 x) (digitMul a0 y)
        q = (a0*b0) : 0 : 0 : mulMartin x y
mulMartin (a0 : 0 : x) (b0 : 1 : y) = mid p q
  where p  = mid p' p''
        p' = 0 : 0 : x
        p''= mid (digitMul b0 x) (digitMul a0 y)
        q = (a0*b0) : 0 : 0 : mulMartin x y
mulMartin (a0 : a1 : x) (b0 : 0 : y) = mid p q
  where p  = mid p' p''
        p' = 0 : 0 : digitMul a1 y
        p''= mid (digitMul b0 x) (digitMul a0 y)
        q = (a0*b0) : (a1*b0) : 0 : mulMartin x y
mulMartin (a0 : a1 : x) (b0 : b1 : y) = mid p q
  where p  = mid p' p''
        p' = (a0*b1): mid (digitMul b1 x) (digitMul a1 y)
        p''= mid (digitMul b0 x) (digitMul a0 y)
        q = (a0*b0) : (a1*b0) : (a1*b1) : mulMartin x y


-- Choose a multiplication algorithm (mulMartin, mulPlume, mulZnorm)

mul :: I -> I -> I
mul = mulMartin 

-- Here is the third multiplication, which doesn't seem to
-- improve things in practice.

mulZnorm :: I -> I -> I
mulZnorm x y = mulMartin (znorm x) (znorm y)


-- Normalize towards zero. The sequence y = znorm x
-- has the following properties:
--   
--   1. y denotes the same number as x, and y = norm y.
--   2. If x denotes zero, then y = repeat 0
--   3. If x doesn't denote zero, then we can read off the
--      the sign of the denoted number by looking at the 
--      the first non-zero digit of y.

znorm :: I -> I
znorm(0:x) = 0:znorm x
znorm(-1:1:x) = 0:znorm(-1:x)
znorm(1: -1:x) = 0:znorm(1:x)
znorm x = x

-- Square function x -> x^2.

sqr :: I -> I

sqr = sqrMartin


sqrZnorm :: I -> I
sqrZnorm x = sqrMartin(znorm x)

sqrMartin (0:x) = 0 : 0 : sqrMartin x
sqrMartin (a0 : 0 : x) = mid p q
  where p  = 0 : digitMul a0 x
        q = (a0*a0) : 0 : 0 : sqrMartin x
sqrMartin (a0 : a1 : x) = mid p q
  where p  = mid p' p''
        p' = (a0*a1): digitMul a1 x
        p''= digitMul a0 x
        q = (a0*a0) : (a1*a0) : (a1*a1) : sqrMartin x


-- Division of a number by an integer

divByInt :: I -> Int -> I

divByInt x n = f x 0
    where f (a:x) s = let t = a + 2 * s 
                      in if t >=  n then  1 : f x (t - n)
                    else if t <= -n then -1 : f x (t + n)
                                    else  0 : f x t


-- Multiplication of number in [-1,1] by an an integer,
-- producing integer and fractional parts.
-- Assume the integer to be positive for the moment.

mulByInt :: I -> Int -> (Int,I)

mulByInt x n = f n
 where f 1 = (0,x)
       f n = let (a,d:y) = f (n `div` 2)
                 (b,z) = (2*a+d,y)
             in if even n 
                then (b,z)
                else let e:t = mid x z
                     in (b+e,t)

