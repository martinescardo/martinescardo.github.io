-- Martin Escardo
-- For CCA'2009, based on older stuff.

module DecidableCloseness 
  (
    close, 
    closeFun, 
    counterFun
  ) where

import BasicArithmetic
import Iquantification
import Selection

-- Are two numbers x and y close up to precision n?
-- I.e., are they indistinguishable in precision n?

close :: Int -> I -> I -> Bool
close n x y = closez n (mid x (compl y))

closez :: Int -> I -> Bool
closez n x = f n (znorm x)
    where f 0 x = True
          f(n+1) (d:x) = (d == 0) && f n x

-- Are two given functions f, g close up to precision n?

closeFun :: Int -> (I -> I) -> (I -> I) -> Bool
closeFun n f g = forEveryReal(\x -> close n (f x) (g x))

-- Find a counter-example to that:

counterFun :: Int -> (I -> I) -> (I -> I) -> I
counterFun n f g = findReal(\x -> not(close n (f x) (g x)))
