-- Martin Escardo
-- For CCA'2009, based on older stuff.

module Iquantification 
   (
    epsilon,
    epsilonNonNegative,
    forEveryI,
    forEveryNonNegativeI,
    forSomeI,
    forSomeNonNegativeI
   ) where

import BasicArithmetic


-- Essentially Berger's 1990 algorithm.


epsilon :: (I -> Bool) -> I

epsilon p = 
  if p(-1 : left) then -1 : left else 1 : right
  where left  = epsilon(\x -> p((-1):x))
        right = epsilon(\x -> p(1:x))


forEveryI, forSomeI :: (I -> Bool) -> Bool

forSomeI p = p(epsilon p)

forEveryI p = not(forSomeI(not.p))


epsilonNonNegative :: (I -> Bool) -> I

epsilonNonNegative p = 
  if p(0 : left) then 0 : left else 1 : right
  where left  = epsilonNonNegative(\x -> p(0:x))
        right = epsilonNonNegative(\x -> p(1:x))


forEveryNonNegativeI, forSomeNonNegativeI :: (I -> Bool) -> Bool

forSomeNonNegativeI p = p(epsilonNonNegative p)

forEveryNonNegativeI p = not(forSomeNonNegativeI(not.p))
 