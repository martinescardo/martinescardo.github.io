-- Martin Escardo
-- For CCA'2009, based on older stuff.

module ModulusOfContinuityLazy (modulusLazy) where

import Iquantification
import BasicArithmetic
import IteratedMidPoint

-- Modulus of uniform continuity on [-1,1]

data LazyNat = Zero | Succ LazyNat
             deriving (Show)

lazyMax Zero y = y
lazyMax x Zero = x
lazyMax (Succ x) (Succ y) = Succ(lazyMax x y)

modulusLazy :: (I -> I) -> (Int -> LazyNat)

modulusLazy f 0 = Zero
modulusLazy f n = if forEveryI(\x -> head(f x) == head (f zero))
              then modulusLazy (tail.f) (n-1) 
              else Succ(lazyMax (modulusLazy (f.((-1):)) n) 
                                (modulusLazy (f.(( 1):)) n))


