-- Martin Escardo
-- For CCA'2009, based on older stuff.

-- The operation bigMid has applications to power series.
-- It also appears in the work of Escardo & Simpson (LICS'2001).

module IteratedMidPoint (bigMid) where

import BasicArithmetic (I,mid)


-- Given a sequence x0,x1,x2,...,xn,... of points of [-1,1], 
-- Compute x0 / 2 + x1 / 4 + x2 / 8 + ... +  xn / 2^(n+1) + ...
--
--          = sum_n xn * 2^(n-1)
--
--          = mid(x0, mid(x1, mid(x2, ...)))

bigMid :: [I] -> I
bigMid = divideBy4.bigMid'

-- Scriven's 2008 algorithm.
--
-- Use an auxiliary representation, namely binary with nine 
-- signed digits:

type Nine  = Int    -- use digits -4,-3,-2,-1,0,1,2,3,4
type I4 = [Nine]    -- Representation of the space [-4,4]


bigMid' :: [I] -> I4
bigMid'((a:b:x):(c:y):s) = (2*a + b + c) : bigMid'((mid x y):s)


-- Division by 4 as a function [-4,4] -> [-1,1]

divideBy4 :: I4 -> I
divideBy4 ((-4):x) = -1 : divideBy4 x
divideBy4 (( 0):x) =  0 : divideBy4 x
divideBy4 (( 4):x) =  1 : divideBy4 x
divideBy4 (a:b:x) = let d = 2 * a + b
                    in if d < -4 then -1 : divideBy4((d+8):x)
                       else if d > 4 then 1 : divideBy4((d-8):x)
                       else 0 : divideBy4(d:x)               
