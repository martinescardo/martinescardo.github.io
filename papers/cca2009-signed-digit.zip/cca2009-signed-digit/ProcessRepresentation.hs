-- Martin Escardo
-- For CCA'2009, based on older stuff.

module ProcessRepresentation 
   (
    Process(Output,Input), 
    toProcess, 
    fromProcess
   ) where

import BasicArithmetic
import Iquantification

data Process = Output Digit Process | Input Process Process Process

toProcess :: (I -> I) -> Process

toProcess f = 
  let h = head(f zero)
  in if forEveryI(\x -> head(f x) == h)
     then Output h (toProcess(tail.f))
     else Input (toProcess(f.((-1):))) 
                (toProcess(f.(  0 :)))
                (toProcess(f.(  1 :)))

fromProcess :: Process -> (I -> I)
fromProcess (Output d p) x = d : fromProcess p x
fromProcess (Input p q r) (-1 : x) = fromProcess p x
fromProcess (Input p q r) ( 0 : x) = fromProcess q x
fromProcess (Input p q r) ( 1 : x) = fromProcess r x
