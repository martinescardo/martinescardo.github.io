-- Martin Escardo
-- For CCA'2009, based on older stuff.

module TentativelyBetterIntegration (halfIntegralBetter) where

-- Not better, actually

import Iquantification
import BasicArithmetic
import IteratedMidPoint

-- We represent a number x in [-1,1] by a sequence a in [I] 
-- such that x = bigMid a.

average :: [I] -> [I] -> [I]
average = zipWith mid

-- Definite integration. Based on A.K. Simpson 1998, but there 
-- are a couple of new ideas, such as using the above 
-- representation.
--
-- Compute integral of f from -1 to 1 divided by 2.


halfIntegral' :: (I -> I) -> [I]

halfIntegral' f = 
  let h = head(f zero)
  in if forEveryI(\x -> head(f x) == h)
     then (repeat h) : halfIntegral'(tail.f)
     else average  (average(halfIntegral'(f.([-1, -1]++)))
                           (halfIntegral'(f.([-1,  1]++))))
                   (average(halfIntegral'(f.([ 1, -1]++)))
                           (halfIntegral'(f.([ 1,  1]++))))

halfIntegralBetter :: (I -> I) -> I
halfIntegralBetter f = bigMid(halfIntegral' f)
