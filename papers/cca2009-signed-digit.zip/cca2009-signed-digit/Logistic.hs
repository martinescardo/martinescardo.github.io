-- Martin Escardo
-- For CCA'2009, based on older stuff.

module Logistic 
  (
    logistic, 
    logistic', 
    logistic''
  ) where

import BasicArithmetic 
import TruncatedArithmetic 
import InefficientMultiplication 

-- Logistic map f(x) = 4x(1-x) as a function [-1,1] -> [-1,1].
-- Interested only in the part [0,1] -> [0,1],

logistic, logistic', logistic'' :: I -> I

logistic  x = mulBy4 (mul x (oneMinus x))    

logistic'  x = mulBy4 (mul'' x (oneMinus x))  

logistic'' x = oneMinus (sqr(g x))        -- 1-(2x-1)^2
       where g ( 1 : x) = x               -- g(x)= max(-1,2x-1) 
             g ( 0 : x) = subOne x
             g (-1 : x) = minusOne

