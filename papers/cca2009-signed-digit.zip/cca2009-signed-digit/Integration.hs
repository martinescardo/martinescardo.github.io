-- Martin Escardo
-- For CCA'2009, based on older stuff.

module Integration (halfIntegral,integral01) where

import Iquantification
import BasicArithmetic
import IteratedMidPoint

-- We represent a number x in [-1,1] by a sequence a in [I] 
-- such that x = bigMid a.

average :: [I] -> [I] -> [I]
average = zipWith mid

-- Definite integration. Based on A.K. Simpson 1998, but there 
-- are a couple of new ideas, such as using the above 
-- representation.
--
-- Compute integral of f from -1 to 1 divided by 2.


halfIntegral' :: (I -> I) -> [I]

halfIntegral' f = 
  let h = head(f zero)
  in if forEveryI(\x -> head(f x) == h)
     then (repeat h) : halfIntegral'(tail.f)
     else average (halfIntegral'(f.((-1):))) (halfIntegral'(f.(1:)))

halfIntegral :: (I -> I) -> I
halfIntegral f = bigMid(halfIntegral' f)

-- Compute integral of f from 0 to 1

integral01' :: (I -> I) -> [I]

integral01' f = 
  let h = head(f zero)
  in if forEveryNonNegativeI(\x -> head(f x) == h)
     then (repeat h) : integral01'(tail.f)
     else average (integral01'(f.(0:))) (integral01'(f.(1:)))

integral01 :: (I -> I) -> I
integral01 f = bigMid(integral01' f)
