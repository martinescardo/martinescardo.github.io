-- Martin Escardo
-- For CCA'2009, based on older stuff.

-- Digression: application to program verification.
-- Buggy multiplication.
-- On purpose - where is the mistake?

module IntensionallyBuggyThings 
   (
    buggyMul, 
    buggySqr
   ) where

import BasicArithmetic

buggyMul (0:x) y = 0 : buggyMul x y
buggyMul x (0:y) = 0 : buggyMul x y
buggyMul (a0 : 0 : x) (b0 : 0 : y) = mid p q
  where p  = 0 : mid (digitMul b0 x) (digitMul a0 y)
        q = (a0*b0) : 0 : 0 : buggyMul x y
buggyMul (a0 : 0 : x) (b0 : b1 : y) = mid p q
  where p  = mid p' p''
        p' = (a0*b1): 0 : digitMul b1 x
        p''= mid (digitMul b0 x) (digitMul a0 y)
        q = (a0*b0) : 0 : 0 : buggyMul x y
buggyMul (a0 : 0 : x) (b0 : 1 : y) = mid p q
  where p  = mid p' p''
        p' = 0 : 0 : x
        p''= mid (digitMul b0 x) (digitMul a0 y)
        q = (a0*b0) : 0 : 0 : buggyMul x y
buggyMul (a0 : a1 : x) (b0 : 0 : y) = mid p q
  where p  = mid p' p''
        p' = 0 : 0 : digitMul a1 y
        p''= mid (digitMul b0 x) (digitMul a0 y)
        q = (a0*b0) : (a1*b0) : 0 : buggyMul x y
buggyMul (a0 : a1 : x) (b0 : b1 : y) = mid p q
  where p  = mid p' p''
        p' = (a0*b1): mid (digitMul b1 x) (digitMul a1 y)
        p''= mid (digitMul b0 x) (digitMul a0 y)
        q = (a0*b0) : (a1*b0) : (a1*a1) : buggyMul x y



-- x |-> x^2

buggySqr :: I -> I

buggySqr (0:x) = 0 : 0 : buggySqr x
buggySqr (a0 : 0 : x) = mid p q
  where p  = 0 : digitMul a0 x
        q = (a0*a0) : 0 : 0 : buggySqr x
buggySqr (a0 : a1 : x) = mid p q
  where p  = mid p' p''
        p' = (a0*a0): digitMul a1 x
        p''= digitMul a0 x
        q = (a0*a0) : (a1*a0) : (a1*a1) : buggySqr x
