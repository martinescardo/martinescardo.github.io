-- Martin Escardo
-- For CCA'2009, based on older stuff.

module ModulusOfContinuityAverage (modulusAverage) where

import Iquantification
import BasicArithmetic
import IteratedMidPoint

-- Modulus of uniform continuity on [-1,1]

modulusAverage :: (I -> I) -> (Int -> Double)

modulusAverage f 0 = 0.0
modulusAverage f n = 
      if forEveryI(\x -> head(f x) == head (f zero))
      then modulusAverage (tail.f) (n-1)
      else 1.0 + 
             (
               (modulusAverage (f.((-1):)) n) 
               +
               (modulusAverage (f.(( 1):)) n)
             ) / 2.0
