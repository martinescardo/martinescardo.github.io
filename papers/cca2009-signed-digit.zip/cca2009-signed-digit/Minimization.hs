-- Martin Escardo
-- For CCA'2009, based on older stuff.

module Minimization (mu) where

mu :: (Int -> Bool) -> Int
mu p = if p 0 then 0 else 1+mu(p.(1+))
