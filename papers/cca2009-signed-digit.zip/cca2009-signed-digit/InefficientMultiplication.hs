-- Martin Escardo
-- For CCA'2009, based on older stuff.

module InefficientMultiplication (mul'') where

import BasicArithmetic
import IteratedMidPoint

mul'' :: I -> I -> I
mul'' x y = bigMid (zipWith digitMul x (repeat y))
