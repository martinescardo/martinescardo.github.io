-- Martin Escardo
-- For CCA'2009, based on older stuff.


module Examples 
  (
    signed_e, 
    signed_e',
    signed_e'',
    signed_e''',
    e, 
    e', 
    e'',
    e''',
    pi', 
    pi'', 
    elementaryExample,
    signedDecimalPi', 
    anIntegral, 
    aBetterIntegral, 
    anotherIntegral, 
    aNestedIntegral,
    integralLogistic,
    logistics, 
    logisticsDouble, 
    logisticsError, 
    closeToItself,
    closeToEachOther,
    infimumTest,
    isThereaBug,
    analyticTest,
    generalTaylor,
    generalPower,
    inverseExample,
    modulusSqr,
    modulusIteratedLogistic,
    modulusIteratedLogistic',
    lmodulusSqr,
    lmodulusIteratedLogistic,
    lmodulusIteratedLogistic',    
    llmodulusSqr,
    llmodulusSqr',
    llmodulusIteratedLogistic,
    llmodulusIteratedLogistic',    
    amodulusSqr,
    amodulusIteratedLogistic,
    amodulusIteratedLogistic',    
  ) where

import BasicArithmetic
import TruncatedArithmetic
import ElementaryFunctions
import Integration
import IntegrationViaProcess
import TentativelyBetterIntegration
import Conversion
import DoubleConversion
import Logistic
import DecidableCloseness
import Iquantification
import IntensionallyBuggyThings
import UnTaylor
import Supremum
import Division
import ModulusOfContinuity
import ModulusOfContinuityLazy
import ModulusOfContinuityLazier
import ModulusOfContinuityAverage

-- The number e, in different ways

signed_e = mulBy2(divByInt (sqr(mexp one)) 5)

e = decimalString signed_e

signed_e' = mulBy4 (divByInt (sqr(mexp one)) 10)

e' = decimalString signed_e'

signed_e'' = (mulBy4.mulBy4) 
             (divByInt ((sqr.sqr)(mexp(1 : zero))) 10)

e'' = decimalString signed_e''

signed_e''' = (mulBy4.mulBy4.mulBy4.mulBy4) 
              (divByInt ((sqr.sqr.sqr)(mexp(0 : 1 : zero))) 10)

e''' = decimalString signed_e'''


-- The number pi

pi' = let (m,x) = mulByInt piDividedBy4 4
      in show m ++ "." ++ decimalString x

pi'' = let (m,x) = mulByInt piDividedBy32 32
       in show m ++ "." ++ decimalString x

signedDecimalPi' = let (m,x) = mulByInt piDividedBy32 32
                   in m : signedDecimal x

-- Random elementary computation

elementaryExample = decimalString(msin (mcos (msin (mexp (repeat 1)))))


-- Some integrals

anIntegral = decimalString(halfIntegral sqr)
aBetterIntegral = halfIntegralBetter sqr
aProcessIntegral = halfIntegralViaProcess sqr
anotherIntegral = halfIntegral id
aNestedIntegral = halfIntegral(\x -> halfIntegral(\y -> 1 : 1 : mul x y))

integralLogistic = decimalString(integral01 logistic)

-- The logistic map

x0 = 0.671875

d0 :: I

d0 = [1,0,1,0,1,1] ++ zero

logistics = map toDouble (iterate logistic'' d0)

dlogistic, dlogistic' :: Double -> Double

dlogistic  x = 4.0 * x * (1.0 - x)
dlogistic' x = 1.0-(2.0 * x - 1.0)^2

logisticsDouble = iterate dlogistic x0

logisticsError = zipWith (-) logistics logisticsDouble

-- closeFun

closeToItself n = closeFun n mexp mexp

closeToEachOther n = closeFun n mexp mcos

-- Infimum

infimumTest = signedDecimal(infimum (\x -> (mid x (sqr x))))

-- Finding bugs (try n = 3 and n = 4)

isThereaBug n = not 
  (forEveryI(\x -> closeFun n (\y -> buggyMul x y) 
                              (\y -> mul y x)))

-- General Taylor series

generalTaylor = decimalString (taylor (repeat one) one)

-- Checking whether a function is not "analytic" 
-- (with slightly non-standard of "analytic").
-- It doesnt' work in practice.

analyticTest :: [Int]
analyticTest = traceAnalytic mexp

-- Inverse

inverseExample = toDouble(inv (mexp one))

-- General power series

generalPower = toDouble(powerf (repeat one) (mexp one))

-- Modulus of continuity

modulusSqr = modulus sqr

modulusIteratedLogistic m n = modulus (power m logistic) n

modulusIteratedLogistic' m n = modulus (power m logistic') n

power :: Int -> (a -> a) -> (a -> a)
power 0 f x = x
power (n+1) f x = f(power n f x)

lmodulusSqr = modulusLazy sqr

lmodulusIteratedLogistic m n = modulusLazy (power m logistic) n

lmodulusIteratedLogistic' m n = modulusLazy (power m logistic') n

llmodulusSqr = modulusLazier sqr

llmodulusIteratedLogistic m n = modulusLazier (power m logistic) n

llmodulusIteratedLogistic' m n = modulusLazier (power m logistic') n

-- Counts how many universal quantifications are needed to compute the modulus:

llmodulusSqr' = modulusLazier' sqr

-- Average modulus of continuity

amodulusSqr = modulusAverage sqr

amodulusIteratedLogistic m n = modulusAverage (power m logistic) n

amodulusIteratedLogistic' m n = modulusAverage (power m logistic') n

{--

Prelude Examples> amodulusIteratedLogistic 4 1
4.8430023193359375
Prelude Examples> modulusIteratedLogistic 4 1
19
Prelude Examples> 

--}