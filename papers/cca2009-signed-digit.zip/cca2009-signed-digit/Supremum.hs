-- Martin Escardo
-- For CCA'2009, based on older stuff.

module Supremum (supremum, infimum) where

import Iquantification
import BasicArithmetic
import TruncatedArithmetic


-- Based on A.K. Simpson 1998.

supremum :: (I -> I) -> I

supremum f = 
  let h = head(f zero)
  in if forEveryI(\x -> head(f x) == h)
     then h : supremum(tail.f)
     else imax (supremum(f.((-1):))) (supremum(f.(1:)))


infimum :: (I -> I) -> I

infimum f = 
  let h = head(f zero)
  in if forEveryI(\x -> head(f x) == h)
     then h : infimum(tail.f)
     else imin (infimum(f.((-1):))) (infimum(f.(1:)))
