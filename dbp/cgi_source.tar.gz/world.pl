#!/usr/local/bin/perl4

print "Content-type: text/html\n\n";
print "<html><head><title>Hello</title></head>\n";
print "<body><h1>Hello world!</h1></body></html>\n";

