module URL (URL) where

type URL = String